import React from 'react'
import "./cart.css";
const Cart = (props) => {
  return (
    <div>{props.store.map((item,index)=>{
        return(
            <div className='main-cart'>
            <h1>{item.name}</h1>
            <h1>{item.phone}</h1>
            </div>
            
            
        )
    })}</div>
  )
}

export default Cart