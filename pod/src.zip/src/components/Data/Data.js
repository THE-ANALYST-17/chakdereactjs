// const Data=[
//     {fname:'utk',age:25,nationality:'indian'},
//     {fname:'arun',age:22,nationality:'indian'},
//     {fname:'vishal',age:23,nationality:'indian'},
//     {fname:'msd',age:40,nationality:'indian'},
//     {fname:'rohit',age:33,nationality:'indian'},
//     {fname:'virat',age:34,nationality:'indian'},
//     {fname:'ponting',age:44,nationality:'indian'},
// ]
//  import React from "react";
//  import { useEffect, useState } from "react";

// const Data = () => {

//    const [user, setusers] = useState([]);

//    const userDetails = async () => {
//        const response = await fetch("https://jsonplaceholder.typicode.com/users")
//        setusers(await response.json());



//    }
//    console.log(user);
//    useEffect(() => {
//        userDetails();
//    }, [])

// }

// export default Data
