import React from "react";
import Nav from "../Navbar/Nav";
import Card from "../Cards/Card";
import Cart from "../Cart/Cart"
// import Data from '../Data/Data'
import { useState, useEffect } from "react";
const App = () => {
  const [user, setusers] = useState([]);
  const [store, setStore] = useState([]);
  const [show,setShow]=useState(false)
  const userDetails = async () => {
    const response = await fetch("https://jsonplaceholder.typicode.com/users");
    setusers(await response.json());
  };
  // console.log(user);
  useEffect(() => {
    userDetails();
  }, []);

  const [state, setState] = useState(0);
  function updateState(item) {
    setStore(store.concat({name:item.name,phone:item.phone}))
    const newupdatestate = (oldstate) => {
      return oldstate + 1;
    };
    setState(newupdatestate);
  }
  console.log(store);
  function updateCart(){
    setShow(true)
  }

  return (
    <>
      <Nav st={state} updateCart={updateCart} />
      <div className="cards">
        {user.map((item, index) => {
          return (
            <Card
              key={index}
              k={item.id}
              firstName={item.name}
              phone={item.phone}
              username={item.username}
              web={item.website}
              update={()=>updateState(item)}
            />
          );
        })}
      </div>
      {/* <Card/> */}
      {show ? <Cart store={store}/> :""}
    </>
  );
};
export default App;
