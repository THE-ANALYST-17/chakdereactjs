import React, { useState } from "react";
import "./card.css";

const Card = (props) => {
  // const [state,setState] = useState(0);
  
  return (
    
        
            <div className="card-elements">
            <p>{props.firstName}</p>
            <p>{props.phone}</p>
            <p>{props.username}</p>
            <p>{props.web}</p>
          <button className="btn1" onClick={props.update}>Add</button>
          {/* <p>{props.st}</p> */}
            </div>
          
        
        
        
          
        
      // <div className="data">
      //   <h2>{props.firstName}</h2>
      // </div>
    
  );
};

export default Card;
